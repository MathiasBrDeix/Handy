import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">M</span>
              </div>
              <span className="text-xl font-bold">ManutençãoFácil</span>
            </div>
            <p className="text-muted-foreground mb-4">
              A melhor plataforma para encontrar profissionais de manutenção residencial.
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
              <Instagram className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
              <Twitter className="w-5 h-5 cursor-pointer hover:text-primary transition-colors" />
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">Serviços</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="hover:text-primary cursor-pointer transition-colors">Hidráulica</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Elétrica</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Pintura</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Marcenaria</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Limpeza</li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Empresa</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="hover:text-primary cursor-pointer transition-colors">Sobre Nós</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Como Funciona</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Seja um Prestador</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Segurança</li>
              <li className="hover:text-primary cursor-pointer transition-colors">Ajuda</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">Contato</h3>
            <div className="space-y-3 text-muted-foreground">
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                <span className="text-sm">contato@manutencaofacil.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span className="text-sm">(11) 9999-9999</span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                <span className="text-sm">São Paulo, SP</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-muted pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">
            © 2024 ManutençãoFácil. Todos os direitos reservados.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <span className="text-muted-foreground text-sm hover:text-primary cursor-pointer transition-colors">
              Termos de Uso
            </span>
            <span className="text-muted-foreground text-sm hover:text-primary cursor-pointer transition-colors">
              Privacidade
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;