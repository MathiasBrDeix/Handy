import { Search, Star, Users, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Hero = () => {
  return (
    <section className="bg-gradient-to-br from-background via-secondary/30 to-background py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 animate-fade-in">
            Manutenção Residencial
            <span className="bg-gradient-hero bg-clip-text text-transparent block">
              Profissional e Confiável
            </span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Conectamos você aos melhores profissionais de manutenção da sua região. 
            Serviços verificados, avaliações reais, preços justos.
          </p>

          {/* Search Section */}
          <div className="bg-card p-6 rounded-2xl shadow-card max-w-2xl mx-auto mb-12">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input 
                  placeholder="Que tipo de serviço você precisa?" 
                  className="h-12 text-lg rounded-xl"
                />
              </div>
              <Button className="h-12 px-8 rounded-xl bg-gradient-hero hover:bg-primary-hover">
                <Search className="w-5 h-5 mr-2" />
                Buscar Profissionais
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-6 h-6 text-primary mr-2" />
                <span className="text-2xl font-bold text-foreground">500+</span>
              </div>
              <p className="text-muted-foreground">Profissionais Verificados</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Star className="w-6 h-6 text-primary mr-2" />
                <span className="text-2xl font-bold text-foreground">4.8</span>
              </div>
              <p className="text-muted-foreground">Avaliação Média</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Shield className="w-6 h-6 text-primary mr-2" />
                <span className="text-2xl font-bold text-foreground">100%</span>
              </div>
              <p className="text-muted-foreground">Serviços Garantidos</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;