import { Wrench, Paintbrush, Zap, Droplets, Hammer, Settings, Wind, Camera } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const services = [
  {
    icon: Droplets,
    title: "Hidráulica",
    description: "Vazamentos, encanamento, instalações",
    color: "text-blue-500"
  },
  {
    icon: Zap,
    title: "Elétrica",
    description: "Instalações, reparos, tomadas",
    color: "text-yellow-500"
  },
  {
    icon: Paintbrush,
    title: "Pintura",
    description: "Paredes, fachadas, acabamentos",
    color: "text-purple-500"
  },
  {
    icon: Hammer,
    title: "Marcenaria",
    description: "Móveis, portas, armários",
    color: "text-orange-500"
  },
  {
    icon: Wind,
    title: "Ar Condicionado",
    description: "Instalação, manutenção, limpeza",
    color: "text-cyan-500"
  },
  {
    icon: Settings,
    title: "Geral",
    description: "Pequenos reparos, montagem",
    color: "text-gray-500"
  },
  {
    icon: Wrench,
    title: "Jardinagem",
    description: "Paisagismo, poda, manutenção",
    color: "text-green-500"
  },
  {
    icon: Camera,
    title: "Segurança",
    description: "Câmeras, alarmes, portões",
    color: "text-red-500"
  }
];

const ServiceCategories = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Todos os Serviços em um Só Lugar
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Encontre profissionais especializados para qualquer tipo de manutenção residencial
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card 
                key={index} 
                className="group cursor-pointer transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1 bg-gradient-card border-border/50"
              >
                <CardContent className="p-6 text-center">
                  <div className="mb-4 flex justify-center">
                    <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                      <IconComponent className={`w-6 h-6 ${service.color} group-hover:text-primary transition-colors`} />
                    </div>
                  </div>
                  <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ServiceCategories;