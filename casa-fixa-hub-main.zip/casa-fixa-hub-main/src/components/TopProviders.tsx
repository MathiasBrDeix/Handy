import { Star, MapPin, CheckCircle, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const providers = [
  {
    id: 1,
    name: "Carlos Silva",
    specialty: "Hidráulica",
    rating: 4.9,
    reviews: 127,
    location: "São Paulo, SP",
    price: "R$ 80/hora",
    verified: true,
    topRated: true,
    image: "/placeholder.svg"
  },
  {
    id: 2,
    name: "Ana Santos",
    specialty: "Pintura",
    rating: 4.8,
    reviews: 89,
    location: "Rio de Janeiro, RJ",
    price: "R$ 70/hora",
    verified: true,
    topRated: false,
    image: "/placeholder.svg"
  },
  {
    id: 3,
    name: "João Oliveira",
    specialty: "Elétrica",
    rating: 4.9,
    reviews: 156,
    location: "Brasília, DF",
    price: "R$ 90/hora",
    verified: true,
    topRated: true,
    image: "/placeholder.svg"
  },
  {
    id: 4,
    name: "Maria Costa",
    specialty: "Limpeza",
    rating: 4.7,
    reviews: 203,
    location: "Salvador, BA",
    price: "R$ 60/hora",
    verified: true,
    topRated: false,
    image: "/placeholder.svg"
  }
];

const TopProviders = () => {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Profissionais Mais Bem Avaliados
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Profissionais verificados com as melhores avaliações da plataforma
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {providers.map((provider) => (
            <Card 
              key={provider.id}
              className="group cursor-pointer transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1 bg-card border-border/50"
            >
              <CardContent className="p-6">
                {/* Header with badges */}
                <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-2">
                    {provider.verified && (
                      <Badge variant="secondary" className="text-xs">
                        <CheckCircle className="w-3 h-3 mr-1 text-success" />
                        Verificado
                      </Badge>
                    )}
                    {provider.topRated && (
                      <Badge variant="default" className="text-xs bg-primary/10 text-primary hover:bg-primary/20">
                        <Award className="w-3 h-3 mr-1" />
                        Top
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Profile section */}
                <div className="flex items-center mb-4">
                  <Avatar className="w-16 h-16 mr-4">
                    <AvatarImage src={provider.image} alt={provider.name} />
                    <AvatarFallback className="bg-gradient-hero text-primary-foreground">
                      {provider.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {provider.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{provider.specialty}</p>
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center mb-2">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-medium text-foreground ml-1">
                    {provider.rating}
                  </span>
                  <span className="text-sm text-muted-foreground ml-1">
                    ({provider.reviews} avaliações)
                  </span>
                </div>

                {/* Location */}
                <div className="flex items-center mb-3">
                  <MapPin className="w-4 h-4 text-muted-foreground mr-1" />
                  <span className="text-sm text-muted-foreground">{provider.location}</span>
                </div>

                {/* Price */}
                <div className="border-t border-border pt-3">
                  <span className="text-lg font-semibold text-primary">{provider.price}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopProviders;